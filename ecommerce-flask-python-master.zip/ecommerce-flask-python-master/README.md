As building ecommerce website has alot of work so we have divided 
whole project into 3 flows-

**Home Page**
 
    1. Showing all active products (title and price)
    2. Showing all active categories (title and price) 

**User Registration Page** 
 
    1. User Registration/SignUp
    2. User Login
    3. User Logout
    
**Category Browse Page**

    1. Show all products along with product name and price  belonging to clicked category
    
**Product Landing Page**

    1. Showing product title, description, regular price, discounted price of a product
    2. Click on add to cart button to add item  
        
**Cart Page** 

    1.Clicks on cart
    2.Cart details along with subtotal for each product(quantity* productprice). Also displays grand total for all products with tax            calculation.
    3.User clicks on remove button to remove products from cart.
    4.User clicks on proceed to checkout.
**Checkout Page**

     1.User enters details on the form and clicks make payment.
     2.Email and text notifications are sent to user on payment.

**Orders Page**

     1.User sees current order details.

**Admin Page**
    
    1. Admin users can see a list of options available to them:
        - Categories
        - Products
        - Users
    2. Categories
        - CRUDE
    3. Products
        - CRUDE
    4. Users
        - Read (view-only)